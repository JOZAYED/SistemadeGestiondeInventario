package com.mycompany.inventario;
import com.mycompany.producto.Producto;
public class Inventario {

    private Producto[][] productos;

    public Inventario() {
        productos = new Producto[2][4];
        
    }
    public void agregarProducto(String nombre, String codigo, int cantidad, double precio) {
        for (int i = 0; i < productos.length; i++) {
           if (productos[i][0] == null) {
               productos[i][0] = new Producto(nombre, codigo, cantidad, precio);
               return; //sale del metodo despues de agregar producto
           }
           
        }
        Producto[][] nuevaMatriz = new Producto[productos.length * 2][4];
        for (int i = 0; i < productos.length; i++) {
            nuevaMatriz[i] = productos[i]; //copiar los productos existentes
        }
        nuevaMatriz[productos.length][0] = new Producto(nombre, codigo, cantidad, precio);
         productos = nuevaMatriz; //Reemplazar la matriz original
    }


    public void eliminarProducto(String codigo) {
           for (int i = 0; i < productos.length; i++) { 
        if (productos[i][0] != null && codigo.equals(productos[i][0].getCodigo())) {
             productos[i][0] = null; //Eliminar el producto 
            return;
           }
           }
    }
    
    public void actualizarProducto(String codigoViejo, String codigoNuevo, String nuevoNombre, int cantidadNueva, double PrecioNuevo) {
        for (int i = 0; i < productos.length; i++) {
            for (int j = 0; j < productos[i].length; j++) {
            if(productos[i][j] != null && codigoViejo.equals(productos[i][j].getCodigo())) {
        
                productos[i][j].setCodigo(codigoNuevo);
                productos[i][j].setNombre(nuevoNombre);
                productos[i][j].setCantidad(cantidadNueva);
                productos[i][j].setPrecio(PrecioNuevo);
                return;
            }
        }
    }
   }

    public void buscarProducto(String codigo) {
        boolean encontrarProducto = false;
        for (int i = 0; i < productos.length; i++) {
            for (int j = 0; j < productos[i].length; j++)
        if (productos[i][0] != null && codigo.equals(productos[i][j].getCodigo())) {

            System.out.println("Producto buscado: ");
            System.out.println("Nombre: " + productos[i][j].getNombre());
            System.out.println("Codigo: " + productos[i][j].getCodigo());
            System.out.println("Cantidad: " + productos[i][j].getCantidad());
            System.out.println("Precio: " + productos[i][j].getPrecio());
               encontrarProducto = true;
            return;
            }
        }
    }
    public void filtrarStockBajo(int umbral) {
        System.out.println("Productos con stock bajo: " + "(menos de " + umbral + " unidades");
        boolean hayStockBajo = false;
        for (int i = 0; i < productos.length; i++) {
            for (int j = 0; j < productos[i].length; j++) {
               if (productos[i][j] != null && productos[i][j].getCantidad() < umbral) {
             hayStockBajo = true;
        System.out.println("Nombre: " + productos[i][j].getNombre() + ", Codigo: " + productos[i][j].getCodigo() + ", Cantidad: " + productos[i][j].getCantidad() + ", Precio: " + productos[i][j].getCodigo());
  
      
                        
            }
         }     
     }
               if (!hayStockBajo) {
                   System.out.println("No hay productos con stock bajo.");
                   
               }
  }
            
    public void ordenarInventario() {
        for (int i = 0; i < productos.length; i++) {
                if (productos[i] != null) {
                        for (int j = 0; j < productos[i].length - 1; j++) {
                            if (productos[i][j] != null && productos[i][j + 1] != null) {
                if (productos[i][j].getCantidad() > productos[i][j + 1].getCantidad()) {
                    
           Producto temporal = productos[i][j];
           productos[i][j] = productos[i][j + 1];
           productos[i][j + 1] = temporal;
                }
            }
       
                    }
                  }
        }
        System.out.println("Inventario ordenado por cantidad");
            }
        
     
   
  public double calcularInventario() {
       double totalInventario = 0.0;
      
       for (int i = 0; i < productos.length; i++) {
           for (int j = 0; j < productos[i].length; j++) {
               if (productos[i][j] != null) {
                   totalInventario += productos[i][j].getCantidad() * productos[i][j].getPrecio();
               }
               
               }
           }
       System.out.println("El valor total del inventario es: $" + totalInventario);
       return totalInventario;
       }

       public Producto[][] getProductos() {
           return productos;
}
}
