package com.mycompany.interfaz;
import com.mycompany.inventario.Inventario;
import com.mycompany.usuario.Usuario;
import com.mycompany.producto.Producto;

import java.io.InputStreamReader;
import java.io.BufferedReader;
import java.io.IOException;


public class Interfaz {

    private Inventario inventario;
    private Usuario usuario;

    public Interfaz() {
       this.inventario = new Inventario();
       this.usuario = new Usuario("");
       
      
       }    
    
           
    public void mostrarInventario() {
                System.out.println("Información de inventario:");
        Producto[][] productos = (Producto[][]) inventario.getProductos();
        
        if (productos != null && productos.length > 0) {
        for (int i = 0; i < productos.length; i++) {
            
            
            if (productos[i] != null) {
            for (int j = 0; j < productos[i].length; j++) {
            
            if (productos[i][j] != null) {
                Producto producto = productos[i][j];                                                                                                                        
                System.out.println("Nombre: " + producto.getNombre() + ", Código: " + producto.getCodigo() + ", Cantidad: " + producto.getCantidad() + ", Precio: " + producto.getPrecio());
             }
           }
        }
     }
    
    } else { 
            System.out.println("No hay productos en el inventario.");
        }
    
          
        }
    public void mostrarInventarioTabular() {
        
               System.out.println("Información de inventario: ");
        System.out.println("-------------------------------------------------------------");
        System.out.printf("%-20s %-15s %-10s %-10s\n", "Nombre", "Codigo", "Cantidad", "Precio");
        System.out.println("-------------------------------------------------------------");
     Producto[][] productos = (Producto[][]) inventario.getProductos();
     

             if (productos == null || productos.length == 0) {
                 System.out.println("No hay productos en el inventario");
                 return;
         }
          
     for (int i = 0; i < productos.length; i++) {     
         if (productos[i] != null) {
         for (int j = 0; j < productos.length; j++) {    
          if (productos[i][j] != null) {
             if (productos[i][j] != null) {
                 Producto producto = productos[i][j];
         
         System.out.printf("%-20s %-15s %-10d %-10.2f\n",
                    producto.getNombre(),
                    producto.getCodigo(),
                    producto.getCantidad(),
                    producto.getPrecio());
         
     }
    }
     }
    }
          System.out.println("-------------------------------------------------------------");
         }
     }
     
    
    

    public void menuPrincipal(Usuario usuario) throws IOException {
        String rol = usuario.getRol();
        
        try (BufferedReader reader = new BufferedReader(new InputStreamReader(System.in))) {
           int opcion = 0;
           do {
               
               if ("administrador".equals(rol)) {
               System.out.println("\n--- Menú de administrador ---");
               System.out.println("1. Agregar Productos al inventario");
               System.out.println("2. Eliminar Productos");
               System.out.println("3. Actualizar detalles de productos");
               System.out.println("4. Buscar Productos");
               System.out.println("5. Filtrar productos con stock bajo");
               System.out.println("6. Ordenar el inventario");
               System.out.println("7. Mostrar Inventario");
               System.out.println("8. Mostrar Inventario Tabular");
               System.out.println("9. Calcular Inventario");
               System.out.println("10. Salir del sistema");
               System.out.print("Seleccione una opción: ");
             opcion = Integer.parseInt(reader.readLine());
               
             switch (opcion) {
             
             
                 case 1:
                                        System.out.println("Ingrese el nombre del producto:");
                       String nombre = reader.readLine();
                       System.out.println("Ingrese el codigo del producto: ");
                       String codigo = reader.readLine();
                       System.out.println("Ingrese la cantidad del producto: ");
                       int cantidad = Integer.parseInt(reader.readLine());
                       System.out.println("Ingrese el precio del producto: ");
                       double precio = Double.parseDouble(reader.readLine());
                       inventario.agregarProducto(nombre, codigo, cantidad, precio);
                       System.out.println("Producto agregado exitosamente!!");
            break;
  
          
                    
                                
             case 2:
             
                 System.out.println("Ingrese el codigo del producto que desea eliminar: ");
                     String codigo1 = reader.readLine();
                     inventario.eliminarProducto(codigo1);
                     System.out.println("Producto con código " + codigo1 + " eliminado exitosamente");
             break;
               
             case 3:
                        System.out.println("Ingrese el codigo del producto a actualizar: ");
                       String codigoViejo = reader.readLine(); 
                       
                       System.out.println("Ingrese el nuevo código: ");
                       String codigoNuevo = reader.readLine();
                       
                       System.out.println("Ingrese el nuevo nombre: ");
                       String nuevoNombre = reader.readLine();
                       
                       System.out.println("Ingrese la nueva cantidad: ");
                       int cantidadNueva = Integer.parseInt(reader.readLine());
                       
                       System.out.println("Ingrese el nuevo precio: ");
                       double precioNuevo = Double.parseDouble(reader.readLine());
                       
                       inventario.actualizarProducto(codigoViejo, codigoNuevo, nuevoNombre, cantidadNueva, precioNuevo);
                       
                         System.out.println("Producto actualizado exitosamente!!");
              break;
             case 4: 
                          System.out.println("Ingrese el codigo del producto a buscar: ");
                     String codigo2 = reader.readLine();
                      inventario.buscarProducto(codigo2);
                       break;
                       
              case 5:
                         System.out.print("Ingrese el umbral de stock bajo: ");
                       int umbral = Integer.parseInt(reader.readLine());
                       inventario.filtrarStockBajo(umbral);
                    break;    
             case 6:
                        inventario.ordenarInventario();
                        System.out.println("Inventario ordenado exitosamente.");
                    break;
                    case 7:
           mostrarInventario();
                    
                    
                 break;
                 
                 case 8:
               mostrarInventarioTabular();
                  
                break;
                
                
                case 9: 
              inventario.calcularInventario();
              
                  break;
                  
                  case 10:
                  
                 System.out.println("Saliendo del sistema...");
                        
                    break;
                default:
                    System.out.println("Opción no válida.");  
                  
              break;
             }
               } else if ("trabajador".equals(rol)) {
                   
                  System.out.println("\n--- Menú de trabajador ---");
                  System.out.println("1. Buscar productos");
                  System.out.println("2. Filtrar productos con stock bajo");
                  System.out.println("3. Mostrar inventario");
                  System.out.println("4. Mostrar inventario tabular");
                  System.out.println("5. Calcular Inventario");
                  System.out.println("6. Salir del sistema");
                  opcion = Integer.parseInt(reader.readLine()); 
                   
                   switch (opcion) {
                       
                       case 1: 
                            System.out.println("Ingrese el codigo del producto a buscar: ");
                     String codigo = reader.readLine();
                      inventario.buscarProducto(codigo);
                      break;
                       case 2: 
                              System.out.print("Ingrese el umbral de stock bajo: ");
                       int umbral = Integer.parseInt(reader.readLine());
                       inventario.filtrarStockBajo(umbral);
                       break;
                       case 3:
                              mostrarInventario();
                          break;    
                       case 4:
                           mostrarInventarioTabular();
                           break;
                           
                       case 5:
                            inventario.calcularInventario(); 
                          break;
                          
                       case 6:
                               
                 System.out.println("Saliendo del sistema...");
                    break;
                    
                default:
                    System.out.println("Opción no válida."); 
              break;
                   }
                   } else if ("empleado de almacen".equals(rol)) {
                   
                  System.out.println("\n--- Menú de trabajador ---");
                  System.out.println("1. Actualizar detalles del producto");
                  System.out.println("2. Ordenar Inventario");
                  System.out.println("3. Mostrar inventario tabular");
                  System.out.println("4. Agregar productos");
                  System.out.println("5. Salir del sistema");
                  opcion = Integer.parseInt(reader.readLine()); 
                   
                   switch (opcion) {
                       
                       case 1: 
                   System.out.println("Ingrese el codigo del producto a actualizar: ");
                       String codigoViejo = reader.readLine(); 
                       
                       System.out.println("Ingrese el nuevo código: ");
                       String codigoNuevo = reader.readLine();
                       
                       System.out.println("Ingrese el nuevo nombre: ");
                       String nuevoNombre = reader.readLine();
                       
                       System.out.println("Ingrese la nueva cantidad: ");
                       int cantidadNueva = Integer.parseInt(reader.readLine());
                       
                       System.out.println("Ingrese el nuevo precio: ");
                       double precioNuevo = Double.parseDouble(reader.readLine());
                       
                       inventario.actualizarProducto(codigoViejo, codigoNuevo, nuevoNombre, cantidadNueva, precioNuevo);
                       
                         System.out.println("Producto actualizado exitosamente!!");
                       case 2:
                             inventario.ordenarInventario();
                        System.out.println("Inventario ordenado exitosamente.");
                          break;    
                       case 3:
                            mostrarInventarioTabular();
                           
                       case 4:
                                   System.out.println("Ingrese el nombre del producto:");
                       String nombre = reader.readLine();
                       System.out.println("Ingrese el codigo del producto: ");
                       String codigo = reader.readLine();
                       System.out.println("Ingrese la cantidad del producto: ");
                       int cantidad = Integer.parseInt(reader.readLine());
                       System.out.println("Ingrese el precio del producto: ");
                       double precio = Double.parseDouble(reader.readLine());
                       inventario.agregarProducto(nombre, codigo, cantidad, precio);
                       System.out.println("Producto agregado exitosamente!!");
                 System.out.println("Saliendo del sistema...");
                    break;
                    
                       case 5:
                default:
                    System.out.println("Opción no válida."); 
              break;
                   }
                   }
                  
           } while (!(("administrador".equals(rol) && opcion == 10) || ("trabajador".equals(rol) && opcion == 6 ) || ("empleado de almacen".equals(rol) && opcion == 5)));
        } catch (IOException e) {
                       System.out.println("Error en la entreada de datos: " + e.getMessage());
        }
    }
}

  
    


               
                 