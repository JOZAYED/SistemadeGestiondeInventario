package com.mycompany.producto;
public class Producto {

    private String nombre;

    private int cantidad;

    private String codigo;

    private double precio;

    
 
 public Producto(String nombre, String codigo, int cantidad, double precio) {
       this.nombre = nombre;
       this.cantidad = cantidad;
       this.codigo = codigo;
       this.precio = precio;
}
    

    public String getNombre() {
        return nombre;
    }

    public int getCantidad() {
        return cantidad;
    }

    public String getCodigo() {
        return codigo;
    }

    public double getPrecio() {
        return precio;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public void setCantidad(int cantidad) {
        this.cantidad = cantidad;
    }

    public void setCodigo(String codigo) {
        this.codigo = codigo;
    }

    public void setPrecio(double precio) {
        this.precio = precio;
    }

   
    @Override
   public String toString() {
       return "Producto [Nombre" + getNombre() + ", Cantidad=" + getCantidad() + ", Codigo=" + getCodigo() + "]";
   }

    
    }
   
