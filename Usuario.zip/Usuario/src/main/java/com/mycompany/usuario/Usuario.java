package com.mycompany.usuario;


import java.io.InputStreamReader;
import java.io.BufferedReader;
import java.io.IOException;
import com.mycompany.interfaz.Interfaz;

public class Usuario {
   private String nombreUsuario;
    private String contrasena;
    private String rol;
    
public Usuario(String nombreUsuario, String contrasena, String rol) {
        this.nombreUsuario = nombreUsuario;
        this.contrasena = contrasena;
        this.rol = rol;

    }
  public Usuario(String rol) {
      this.rol = rol;
  }
   
  public String getRol() {
      return rol;
  }
  public void setRol(String rol) {
      this.rol = rol;
  }

    public void gestionPermisos() {
         System.out.println("Gestión de permisos: " + rol);
            
            switch (rol) {
                case "administrador":
                    System.out.println("Acceso completo:");
                    System.out.println("~ Agregar productos al inventario.");
                    System.out.println("~ Eliminar productos. ");
                    System.out.println("~ Actualizar detalles.");
                    System.out.println("~ Buscar Productos.");
                    System.out.println("~ Filtrar productos con stock bajo.");
                    System.out.println("~ Ordenar el inventario.");
                    System.out.println("~ Mostrar inventario");
                    System.out.println("~ Mostrar inventario tabular");
                     System.out.println("~ Calcular inventario");
                    break;
                    
                case "trabajador":
                    System.out.println("Acceso limitado:");
                    System.out.println("~ Buscar productos.");
                    System.out.println("~ Filtrar productos con stock bajo.");
                    System.out.println("~ Mostrar inventario.");
                    System.out.println("~ Mostrar inventario tabular.");
                    System.out.println("~ Calcular inventario tabular.");
                    break;
                    
                    case "empleado de almacen":
                    System.out.println("~ Actualizar detalles del producto.");
                    System.out.println("~ Ordenar inventario.");
                    System.out.println("~ Mostrar inventario tabular.");
                    System.out.println("~ Agregar productos al inventario");
                    
                    break;
                    
                default: 
                    System.out.println("No reconocido rol. No se puede determinar el acceso.");
                    break;
            }
            }
    
              

   
              public boolean autenticacion(String nombreUsuario, String contrasena) {
        return this.nombreUsuario.equals(nombreUsuario) && this.contrasena.equals(contrasena);
              }

    
    public static void main(String[] args) throws IOException {
        try {
    
         BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
            
         Usuario usuario = new Usuario("Pedro", "1234", "");
          
         boolean autenticado = false;
         while (!autenticado) {
         System.out.print("Ingrese su nombre de usuario: ");
         String nombreUsuario = reader.readLine();
         
         System.out.print("Ingrese su contraseña: ");
         String contrasena = reader.readLine();
        
         
         if (usuario.autenticacion(nombreUsuario, contrasena)) {
             System.out.println("Autenticación exitosa");
                autenticado = true;
         } else {
             System.out.println("Credenciales incorrectas. Por favor, intente nuevamente");
         }  
         }    
         
            
        String rol = "";
        
        boolean rolValido = false;
        
        while(!rolValido) {
               System.out.print("Ingrese su rol (administrador/trabajador/empleado de almacen): ");
            rol = reader.readLine().toLowerCase();
             
            if (rol.equals("administrador") || rol.equals("trabajador") || rol.equals("empleado de almacen")) {
            rolValido = true;
                usuario.setRol(rol); 
            usuario.gestionPermisos();
            
           
            } else {
                System.out.println("Rol inválido. Por favor intente nuevamente");
            }
         }
        Interfaz interfaz = new Interfaz();
           interfaz.menuPrincipal(usuario);
        } catch (IOException e) {
            System.out.println("Error de la entrada de datos: " + e.getMessage());
        }
    }
}

        
    

    
  